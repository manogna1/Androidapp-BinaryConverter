package com.example.s531505.binaryconverter;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    String output="";
    public void one(View v){
        Button btn=findViewById(R.id.btn1);
        output+=btn.getText().toString();
        TextView tv=findViewById(R.id.sourcemainTV);
        tv.setText(output);
        TextView srctv=findViewById(R.id.sourcemainTV);
        TextView contv=findViewById(R.id.convertedoutputTV);
        String in=srctv.getText().toString();
        int number=Integer.parseInt(in);
        String bin = Integer.toBinaryString(number);
        contv.setText(bin);
    }
    public void two(View v){
        Button btn=findViewById(R.id.btn2);
        output+=btn.getText().toString();
        TextView tv=findViewById(R.id.sourcemainTV);
        tv.setText(output);
        TextView srctv=findViewById(R.id.sourcemainTV);
        TextView contv=findViewById(R.id.convertedoutputTV);
        String in=srctv.getText().toString();
        int number=Integer.parseInt(in);
        String bin = Integer.toBinaryString(number);
        contv.setText(bin);
    }
    public void three(View v){
        Button btn=findViewById(R.id.btn3);
        output+=btn.getText().toString();
        TextView tv=findViewById(R.id.sourcemainTV);
        tv.setText(output);
        TextView srctv=findViewById(R.id.sourcemainTV);
        TextView contv=findViewById(R.id.convertedoutputTV);
        String in=srctv.getText().toString();
        int number=Integer.parseInt(in);
        String bin = Integer.toBinaryString(number);
        contv.setText(bin);
    }
    public void four(View v){
        Button btn=findViewById(R.id.btn4);
        output+=btn.getText().toString();
        TextView tv=findViewById(R.id.sourcemainTV);
        tv.setText(output);
        TextView srctv=findViewById(R.id.sourcemainTV);
        TextView contv=findViewById(R.id.convertedoutputTV);
        String in=srctv.getText().toString();
        int number=Integer.parseInt(in);
        String bin = Integer.toBinaryString(number);
        contv.setText(bin);
    }
    public void five(View v){
        Button btn=findViewById(R.id.btn5);
        output+=btn.getText().toString();
        TextView tv=findViewById(R.id.sourcemainTV);
        tv.setText(output);
        TextView srctv=findViewById(R.id.sourcemainTV);
        TextView contv=findViewById(R.id.convertedoutputTV);
        String in=srctv.getText().toString();
        int number=Integer.parseInt(in);
        String bin = Integer.toBinaryString(number);
        contv.setText(bin);
    }
    public void six(View v){
        Button btn=findViewById(R.id.btn6);
        output+=btn.getText().toString();
        TextView tv=findViewById(R.id.sourcemainTV);
        tv.setText(output);
        TextView srctv=findViewById(R.id.sourcemainTV);
        TextView contv=findViewById(R.id.convertedoutputTV);
        String in=srctv.getText().toString();
        int number=Integer.parseInt(in);
        String bin = Integer.toBinaryString(number);
        contv.setText(bin);
    }
    public void seven(View v){
        Button btn=findViewById(R.id.btn7);
        output+=btn.getText().toString();
        TextView tv=findViewById(R.id.sourcemainTV);
        tv.setText(output);
        TextView srctv=findViewById(R.id.sourcemainTV);
        TextView contv=findViewById(R.id.convertedoutputTV);
        String in=srctv.getText().toString();
        int number=Integer.parseInt(in);
        String bin = Integer.toBinaryString(number);
        contv.setText(bin);
    }
    public void eight(View v){
        Button btn=findViewById(R.id.btn8);
        output+=btn.getText().toString();
        TextView tv=findViewById(R.id.sourcemainTV);
        tv.setText(output);
        TextView srctv=findViewById(R.id.sourcemainTV);
        TextView contv=findViewById(R.id.convertedoutputTV);
        String in=srctv.getText().toString();
        int number=Integer.parseInt(in);
        String bin = Integer.toBinaryString(number);
        contv.setText(bin);
    }
    public void nine(View v){
        Button btn=findViewById(R.id.btn9);
        output+=btn.getText().toString();
        TextView tv=findViewById(R.id.sourcemainTV);
        tv.setText(output);
        TextView srctv=findViewById(R.id.sourcemainTV);
        TextView contv=findViewById(R.id.convertedoutputTV);
        String in=srctv.getText().toString();
        int number=Integer.parseInt(in);
        String bin = Integer.toBinaryString(number);
        contv.setText(bin);
    }
    public void zero(View v){
        Button btn=findViewById(R.id.btn0);
        output+=btn.getText().toString();
        TextView tv=findViewById(R.id.sourcemainTV);
        tv.setText(output);
        TextView srctv=findViewById(R.id.sourcemainTV);
        TextView contv=findViewById(R.id.convertedoutputTV);
        String in=srctv.getText().toString();
        int number=Integer.parseInt(in);
        String bin = Integer.toBinaryString(number);
        contv.setText(bin);
    }
    public void clear(View v){
        TextView srctv=findViewById(R.id.sourcemainTV);
        TextView contv=findViewById(R.id.convertedoutputTV);
        output="";
        srctv.setText("");
        contv.setText("");
    }
    public void convert8(View v){
        TextView srctv=findViewById(R.id.sourcemainTV);
        TextView contv=findViewById(R.id.convertedoutputTV);
        String i=srctv.getText().toString();
        int number=Integer.parseInt(i);
        String bin = Integer.toOctalString(number);
        contv.setText(bin);
    }
    public void convert16(View v){
        TextView srctv=findViewById(R.id.sourcemainTV);
        TextView contv=findViewById(R.id.convertedoutputTV);
        String i=srctv.getText().toString();
        int num=Integer.parseInt(i);
        String bin = Integer.toHexString(num);
        contv.setText(bin);
    }
    public void minus(View v){
        Button bt=findViewById(R.id.btmin);
        output=output+bt.getText().toString();
        TextView mintv=findViewById(R.id.sourcemainTV);
        mintv.setText(output);
    }
    public void delete(View v){
        Button bt=findViewById(R.id.btdel);
        output = output.substring(0,output.length()-1);
        TextView deltv=findViewById(R.id.sourcemainTV);
        deltv.setText(output);
    }
}
